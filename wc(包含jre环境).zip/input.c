#include <stdio.h>
//
     //asfgd
int main()
{
	int  a = 10;
	int  b = a;
	printf("%d\n",b);
}
a//asd
   a//asd
  a   //
  a   //   asd
  a    / /

sadfg
			